# NIM/Nama  : 19622217/Lydia Gracia
# Tanggal   : 1 November 2022
# Deskripsi : Program mengubah nilai pada array sampai menjadi nilai nol semua dengan mengurangkan dengan nilai minimal bukann 0; input: banyak nilai, nilai; output: langkah-langkah pada tiap pengoperasian hingga kondisi akhir dipenuhi

# KAMUS
# n: int
# arr: array [0..n-1] of int
# i: int
# isZero: bool
# minimal: int

def min():
    # mencari nilai minimal yang tidak 0
    global n
    global arr
    global minimal

    # KAMUS LOKAL
    # i: int
    # initiate: bool

    # ALGORITMA
    initiate=False # inisiasi nilai minimal belum ditemukan
    i=0
    # perulangan mengecek nilai minimal
    while (i<n):
        if (arr[i]!=0): # anggota yang dipertimbangkan adalah anggota bukan 0
            if (initiate==False):
                initiate=True
                minimal=arr[i]
            else: # (initiate==True): sudah pernah ditemukan nilai bukan 0 yang menjadi nilai minimal sementara
                if (arr[i]<minimal):
                    minimal=arr[i]
                # else:
                    # (arr[i]>=minimal): nilai minimal sementara masih benar
        # else:
            #(arr[i]==0): anggota bernilai 0 tidak dipertimbangkan
        i+=1
    return minimal

def zero():
    # mengecek apakah semua anggota array bernilai 0
    global n
    global arr
    global isZero
    
    # KAMUS LOKAL
    # i: int

    # ALGORITMA
    isZero=True
    for i in range (n):
        if (arr[i]!=0):
            isZero=False# ada anggota bukan 0
        # else: (arr[i]==0) kondisi semua 0 masih terpenuhi
    return isZero

# ALGORITMA PROGRAM UTAMA
n=int(input("Masukkan banyak nilai: "))

# inisiasi array
arr=[0 for i in range (n)]

# input nilai array
# asumsi setiap nilai awal array >=0
for i in range (n):
    arr[i]=int(input(f"Masukkan nilai ke-{i+1}: "))

# print array
isZero=False # inisiasi array awal memiliki anggota bukan 0
minimal=0 # inisiasi nilai minimal array awal untuk print keadaan pertama
while (isZero==False):
    for i in range (n):
        if (arr[i]!=0):
            arr[i]-=minimal
        # else:
            # (arr[i]==0): tidak dilakukan modifikasi pada anggota array 0
        print(arr[i], end=" ")
    print()
    isZero=zero() # cek ulang apakah semua anggota array 0 setelah modifikasi
    minimal=min() # cek ulang nilai minimal array setelah modifikasi
    
    # debugging station
    # print(isZero, minimal)